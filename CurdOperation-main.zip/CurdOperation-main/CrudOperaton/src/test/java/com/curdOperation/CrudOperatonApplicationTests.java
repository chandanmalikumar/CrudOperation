package com.curdOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperatonApplicationTests {

	@Test
	void contextLoads() {
	}

}
